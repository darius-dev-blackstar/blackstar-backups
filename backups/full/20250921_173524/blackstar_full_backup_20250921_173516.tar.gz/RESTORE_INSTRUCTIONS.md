# Instrucciones de Restauración - BlackStar Medical

## Restaurar desde Backup Completo

### 1. Preparar el Servidor de Destino
```bash
# Instalar dependencias
sudo apt update
sudo apt install -y docker.io docker-compose git

# Crear directorio del proyecto
sudo mkdir -p /var/www/blackstar
sudo chown $USER:$USER /var/www/blackstar
cd /var/www/blackstar
```

### 2. Restaurar Archivos del Proyecto
```bash
# Extraer archivos del proyecto
tar -xzf code_backup_*.tar.gz

# Instalar dependencias
cd backend && npm install
cd ../frontend/admin-dashboard && npm install
cd ../frontend/client-admin && npm install
cd ../form-app-v2 && npm install
```

### 3. Restaurar Base de Datos
```bash
# Iniciar solo PostgreSQL
docker-compose up -d postgres

# Esperar a que esté listo
sleep 30

# Restaurar base de datos
gunzip -c db_backup_*.sql.gz | docker exec -i blackstar-postgres psql -U blackstar_user -d blackstar_medical
```

### 4. Restaurar Redis (opcional)
```bash
# Iniciar Redis
docker-compose up -d redis

# Copiar dump de Redis
docker cp redis_backup_*.rdb blackstar-redis:/data/dump.rdb

# Reiniciar Redis para cargar el dump
docker-compose restart redis
```

### 5. Restaurar Volúmenes (si es necesario)
```bash
# Para cada volumen
docker volume create postgres_data
docker run --rm -v postgres_data:/target -v $(pwd):/backup busybox sh -c "cd /target && tar -xzf /backup/volume_*.tar.gz"
```

### 6. Iniciar Todos los Servicios
```bash
# Iniciar todos los servicios
docker-compose up -d

# Verificar estado
docker-compose ps
```

### 7. Verificar Funcionamiento
```bash
# Verificar logs
docker-compose logs backend
docker-compose logs admin-dashboard
docker-compose logs client-dashboard

# Verificar endpoints
curl http://localhost:4000/health
curl http://localhost:3000
curl http://localhost:3002
```
